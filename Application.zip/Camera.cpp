#include "Camera.h"

using namespace camera;

Camera::Camera(glm::vec3 position, glm::vec3 up, float yaw , float pitch)
	:Front(glm::vec3(0.0f, 0.0f, -1.0f)), MovementSpeed(SPEED), MouseSensitivity(SENSITIVITY), Zoom(ZOOM)
{
	Position = position;
	WorldUp = up;
	Camera::yaw = yaw;
	Camera::pitch = pitch;
	UpdateCameraVector();
}

Camera::Camera(float posX, float posY, float posZ, float upX, float upY, float upZ, float yaw = YAW, float pitch = PITCH)
	:Front(glm::vec3(0.0f,0.0f,-1.0f)), MovementSpeed(SPEED), MouseSensitivity(SENSITIVITY), Zoom(ZOOM)
{
	Front = glm::vec3(posX, posY, posZ);
	WorldUp = glm::vec3(upX, upY, upZ);
	Camera::yaw = yaw;
	Camera::pitch = pitch;
	UpdateCameraVector();
}

void Camera::UpdateCameraVector()
{
	glm::vec3 front;
	front.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
	front.y = sin(glm::radians(pitch));
	front.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));
	Front = glm::normalize(front);

	Right = glm::normalize(glm::cross(Front, WorldUp));
	Up = glm::normalize(glm::cross(Right, Front));
}

glm::mat4 Camera::GetViewMatrix()
{
	return glm::lookAt(Position, (Position + Front), Up);
}

void Camera::ProcessKeyboard(Camera_Movement movement, float deltatime)
{
	float velocity = MovementSpeed * deltatime;
	if (movement == Camera_Movement::FORWARD)
		Position += Front * velocity;
	if (movement == BACKWARD)
		Position -= Front * velocity;
	if (movement == RIGHT)
		Position += Right * velocity;
	if (movement == LEFT)
		Position -= Right * velocity;

}

void camera::Camera::ProcessMouseMovement(float xoffset, float yoffset, GLboolean contrainPitch)
{
	xoffset *= MouseSensitivity;
	yoffset *= MouseSensitivity;

	yaw += xoffset;
	pitch += yoffset;

	// make sure that when pitch is out of bounds, screen doesn't get flipped
	if (contrainPitch)
	{
		if (pitch > 89.0f)
			pitch = 89.0f;
		if (pitch < -89.0f)
			pitch = -89.0f;
	}

	// update Front, Right and Up Vectors using the updated Euler angles
	UpdateCameraVector();
}

void camera::Camera::ProcessMouseScroll(float yoffset)
{
	Zoom -= (float)yoffset;
	if (Zoom < 1.0f)
		Zoom = 1.0f;
	if (Zoom > 45.0f)
		Zoom = 45.0f;
}
